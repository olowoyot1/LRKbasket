import { prisma } from './prisma';
import { stockDeltasForOrderItems } from './orderStock';

export class InsufficientStockError extends Error {
  constructor(public productId: string) {
    super('Insufficient stock to restore this order');
  }
}

/** Atomically changes an order status and keeps its reserved stock in sync. */
export async function setOrderStatus(id: string, newStatus: 'PENDING' | 'PAID' | 'FAILED') {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id }, include: { items: true } });
    if (!order) return null;
    if (order.status === newStatus) return order;

    const deltas = await stockDeltasForOrderItems(order.items, tx);

    if (newStatus === 'FAILED' && order.status !== 'FAILED') {
      for (const { productId, qty } of deltas) {
        await tx.product.update({ where: { id: productId }, data: { stock: { increment: qty } } });
      }
    } else if (newStatus !== 'FAILED' && order.status === 'FAILED') {
      for (const { productId, qty } of deltas) {
        const updated = await tx.product.updateMany({
          where: { id: productId, stock: { gte: qty } },
          data: { stock: { decrement: qty } },
        });
        if (updated.count !== 1) throw new InsufficientStockError(productId);
      }
    }

    return tx.order.update({ where: { id }, data: { status: newStatus }, include: { items: true } });
  }, { isolationLevel: 'Serializable' });
}
