import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { sendCustomerOrderConfirmation } from '@/lib/email';

export async function POST(req: NextRequest) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 });

  const rawBody = await req.text();
  const signature = req.headers.get('x-paystack-signature');
  const expected = crypto.createHmac('sha512', secret).update(rawBody).digest('hex');
  if (!signature || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  let event: any;
  try { event = JSON.parse(rawBody); } catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }); }
  if (event.event !== 'charge.success') return NextResponse.json({ received: true });

  const reference = typeof event.data?.reference === 'string' ? event.data.reference : undefined;
  if (!reference) return NextResponse.json({ received: true });

  const order = await prisma.order.findUnique({ where: { reference }, include: { items: true } });
  if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });

  const amount = Number(event.data?.amount);
  const currency = event.data?.currency;
  if (!Number.isInteger(amount) || amount !== order.total * 100 || currency !== 'NGN') {
    console.error('Rejected Paystack webhook amount/currency mismatch', { reference, amount, expected: order.total * 100, currency });
    return NextResponse.json({ error: 'Payment mismatch' }, { status: 400 });
  }

  // Only the first successful transition sends the confirmation email. Webhook retries are harmless.
  const { count } = await prisma.order.updateMany({
    where: { id: order.id, status: 'PENDING', channel: 'PAYSTACK' },
    data: { status: 'PAID' },
  });

  if (count > 0) {
    await sendCustomerOrderConfirmation({
      reference: order.reference,
      customerName: order.customerName,
      email: order.email,
      phone: order.phone,
      address: order.address,
      channel: 'PAYSTACK',
      items: order.items,
      subtotal: order.subtotal,
      deliveryFee: order.deliveryFee,
      total: order.total,
    });
  }

  return NextResponse.json({ received: true });
}
