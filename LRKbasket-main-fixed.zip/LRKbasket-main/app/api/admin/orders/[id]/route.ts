import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { isAdminRequest } from '@/lib/adminAuth';
import { setOrderStatus, InsufficientStockError } from '@/lib/orderStatus';

const bodySchema = z.object({ status: z.enum(['PENDING', 'PAID', 'FAILED']) });

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  if (!isAdminRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const parsed = bodySchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: 'Invalid status' }, { status: 400 });

  try {
    const order = await setOrderStatus(params.id, parsed.data.status);
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    return NextResponse.json({ order });
  } catch (err) {
    if (err instanceof InsufficientStockError) {
      return NextResponse.json({ error: 'Not enough stock to reinstate this order. Adjust stock first.' }, { status: 409 });
    }
    console.error('Order status update failed:', err);
    return NextResponse.json({ error: 'Could not update order' }, { status: 500 });
  }
}
